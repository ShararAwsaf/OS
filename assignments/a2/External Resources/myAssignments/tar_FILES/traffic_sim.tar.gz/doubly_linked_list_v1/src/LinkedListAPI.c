# include <stdio.h>
# include <stdlib.h>
# include <ctype.h>

# include "LinkedListAPI.h"

List *initializeList(void (*printFunction)(void *toBePrinted),void (*deleteFunction)(void *toBeDeleted),int (*compareFunction)(const void *first,const void *second)){
	List * aList;
	aList = malloc(sizeof(List));
	aList->head = NULL;
	aList->tail = NULL;
	
	aList->printNode = printFunction;
	aList->deleteNode = deleteFunction;
	aList->compare = compareFunction;
	
	return aList;
}

void printForward(List * list){
	Node * temp;
	temp = list -> head;
	
	while(temp!=NULL) {
		list->printNode(temp->data);
		temp = temp->next;
	}
}

void printBackwards(List * list){
	Node * temp;
	temp = list -> tail;
	
	while(temp!=NULL) {
		list->printNode(temp->data);
		temp = temp->previous;
	}
}

void * getFromFront(List * list){
	return list->head -> data;
}

void * getFromBack(List * list){
	return list->tail-> data;
}

void insertSorted(List *list, void *toBeAdded){
	Node * temp,*aNode;
	temp = list->head;
	
	if(temp == NULL){
		aNode = malloc(sizeof(Node));
		aNode -> data = toBeAdded;
		aNode -> next = NULL;
		aNode -> previous = NULL;
		list->head = aNode;
		list->tail = aNode;
		return;
	}
		
	while(temp->next != NULL) {
		
		if(list->compare(toBeAdded,temp->data)>=0 && list->compare(toBeAdded,temp->next->data)<=0){
			aNode = malloc(sizeof(Node));
			aNode->data = toBeAdded;
			aNode -> previous = temp;
			aNode->next = temp->next;
			temp->next = aNode;
			
			return;
		}
		temp = temp -> next;
	}
	
	aNode = malloc(sizeof(Node));
	aNode -> data = toBeAdded;
	temp->next = aNode;
	aNode -> next = NULL;
	aNode -> previous = temp;
	list -> tail = aNode;
	
}
