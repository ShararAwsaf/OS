****************************************************
Sharar Mahmood                          0955835
CIS 2520                                Lab 5
sharar@uoguelph.ca                    Oct 15, 2017
****************************************************

Program Description
****************************************************
Main Program : Creates a stack one for integers storage. The program runs a loop and prompts user to ask for a number. The program stops upon entering negative number.
Otherwise, is stack is empty the number os stored in stack and then if the next number is smaller than the first number it is placed on top of the previous number.
However, upon entering a bigger number the stack is popped off until the number is bigger than some other number and if it is the biggest of all the numbers in stack
the size of stack becomes 1 containing that number only.In this way, the loop continues and the program ends by entering negative number.

Additional Program  Details
****************************************************
Complie and Run Main Program:

To compile main program give the command "make program" on the command line 

Executable “program” will be created in the bin upon successful compilation.

To run the program go to command line and type "cd bin" to change directory to bin and give the command "./program" to run

Assumptions or Limitations
****************************************************
No known limitations
No other additional features

